import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup,Validators } from '@angular/forms';
import { LoginService } from '../login.service';
@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss']
})
export class LoginComponent implements OnInit {

  constructor(private login:LoginService) { }

  profileForm=new FormGroup(
    {
      email: new FormControl('',[Validators.required,Validators.email]),
      password: new FormControl('',[Validators.required,Validators.minLength(5)])

    }
  )
    get email()
    {
      return this.profileForm.get('email')
    }
    get password()
    {
      return this.profileForm.get('password')
    }
    onSubmit(data:any) {
      console.log(data)
      this.login.loginData(data);
      
      }
  ngOnInit(): void {
  }

}
