import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { UsersService } from '../users.service';
@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.scss']
})
export class RegisterComponent implements OnInit {
  file:any
  constructor(private user:UsersService) { }
  ngOnInit(): void {
  }
  // registerUser(data:any)
  // { 
    
  //   console.log(data);
  //   this.user.registerUser(data)

  // }
  setImage(event:any){
    this.file=event.target.files[0]
    console.log(this.file);
  }
  registerUser(data:any){
    console.log(data);
   let formdata= new FormData();
   // formdata.append("userdata",data);
   formdata.append("image",this.file,this.file.name)
   formdata.append("username",data.username)
   formdata.append("password",data.password)
   formdata.append("email",data.email)
   formdata.append("date",data.date)
   formdata.append("phone",data.phone)
   formdata.append("country",data.country)
   console.log(formdata)
    this.user.registerUser(formdata)
 
    }
 
  registerForm = new FormGroup(
    { 
      username: new FormControl('',[Validators.required,Validators.pattern('[a-zA-Z ]*')]),
      email: new FormControl('',[Validators.required,Validators.email]),
      password: new FormControl('',[Validators.required,Validators.minLength(8)]),
      date: new FormControl('',[Validators.required]),
      phone: new FormControl('',[Validators.required]),
      country: new FormControl('',Validators.required,),
    }
  )
  get email()
  {
    return this.registerForm.get('email')
  }
  get password()
  {
    return this.registerForm.get('password')
  }
  
  get username()
  {
    return this.registerForm.get('username')
  }
   
  get date()
  {
    return this.registerForm.get('date')
  }
  
   
  get phone()
  {
    return this.registerForm.get('phone')
  }
   
  get country()
  {
    return this.registerForm.get('country')
  }

  

}
