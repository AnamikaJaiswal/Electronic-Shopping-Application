import { Injectable } from '@angular/core';
import { HttpClient} from '@angular/common/http';
import { Router } from '@angular/router';
@Injectable({
  providedIn: 'root'
})
export class LoginService {

  user:any;
 constructor(private http: HttpClient,private router:Router) { }
  loginData(data:any){
    console.log(data);
    return this.http.post('http://127.0.0.1:8000/login', data).subscribe(res =>{
      console.log(res);

      if(res!=0){
        // alert("login successfully");
        this.user=res;
        sessionStorage.setItem("user",this.user.id);
        this.router.navigate(['profile']);
      }
      else{
        alert("Please enter correct username or password");
      //this.profileForm.reset();
      this.router.navigate(['login']);
      window.location.reload();
      }     
    });
  }
 
}
