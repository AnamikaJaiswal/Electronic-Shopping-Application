import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-allpost',
  templateUrl: './allpost.component.html',
  styleUrls: ['./allpost.component.scss']
})
export class AllpostComponent implements OnInit {
 
  constructor() { }

  ngOnInit(): void {
  }
  createShout(){
    // console.log('form data is ', this.createshoutform.value);
    // this.shoutservice.onSend(this.createshoutform.value);
    
  }
}
