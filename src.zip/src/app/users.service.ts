import { Injectable } from '@angular/core';
import {HttpClient} from '@angular/common/http';

import { Router } from '@angular/router';
@Injectable({
  providedIn: 'root'
})
export class UsersService {

  constructor(private http:HttpClient,private router:Router) { }
  getData()
{
  let url="http://127.0.0.1:8000/users"
  return this.http.get(url);
}
registerUser(data:any)
{
 
  this.http.post('http://127.0.0.1:8000/users',data).subscribe();
  console.log(data);
  this.router.navigate(['login']);
}
}
