<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\users;
use Illuminate\Support\Facades\Hash;
class UserController extends Controller
{
     function getData()
     {
         return users::all();
     }
     function postData(Request $req)
     {   
         $image_name=time(). "_" .$req->file('image')->getClientOriginalName();
         $req->image->storeAs('images',$image_name); 

         $user=new users;
         $user->username=$req->username;
         $user->email=$req->email;
         $user->password=Hash::make($req->password);
         $user->date=$req->date;
         $user->phonenumber=$req->phone;
         $user->country=$req->country;
         $user->image_name=$image_name;
         
         $user->save();
        
 }

     function login(Request $req)
     {
        $user= users::where('email',$req->email)->where('status',1)->first();
        if(!$user || !Hash::check($req->password,$user->password)){
          return 0;
         
        }
       return response($user,201);
           
    }
}
